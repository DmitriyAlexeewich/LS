public class GunShootVectorStartPoint : GunShootVectorPoint
{
}
