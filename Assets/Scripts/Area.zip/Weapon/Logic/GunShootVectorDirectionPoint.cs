public class GunShootVectorDirectionPoint : GunShootVectorPoint
{
    
}
