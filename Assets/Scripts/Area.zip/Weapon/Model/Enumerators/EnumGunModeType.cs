﻿using UnityEngine;

namespace Assets.Scripts.Weapon.Model.Enumerators
{
    public enum EnumGunModeType
    {
        First = 1,
        Second = 2,
        Third = 3
    }
}
