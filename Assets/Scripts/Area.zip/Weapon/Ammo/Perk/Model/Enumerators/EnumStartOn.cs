﻿namespace Assets.Scripts.Weapon.Ammo.Perk.Model.Enumerators
{
    public enum EnumStartOn
    {
        OnBulletStart = 1,
        OnBulletHit = 2
    }
}
