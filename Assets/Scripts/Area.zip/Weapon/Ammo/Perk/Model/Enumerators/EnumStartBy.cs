﻿namespace Assets.Scripts.Weapon.Ammo.Perk.Model.Enumerators
{
    public enum EnumStartBy
    {
        None = 0,
        Time = 1,
        Distance = 2
    }
}
