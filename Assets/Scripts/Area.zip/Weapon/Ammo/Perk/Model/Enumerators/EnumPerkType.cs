﻿namespace Assets.Scripts.Weapon.Ammo.Perk.Model.Enumerators
{
    public enum EnumPerkType
    {
        CreateBullet = 1,
        CreateZone = 2,
        ModifyParameters = 3
    }
}
