﻿namespace Assets.Scripts.Weapon.Ammo.Perk.Inheritors.CreateObject.Enumerators
{
    public enum EnumSpawningObjectType
    {
        Zone = 1,
        Bullet = 2
    }
}
