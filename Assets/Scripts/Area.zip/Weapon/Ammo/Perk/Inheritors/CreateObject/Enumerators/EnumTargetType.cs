﻿namespace Assets.Scripts.Weapon.Ammo.Perk.Inheritors.CreateObject.Enumerators
{
    public enum EnumTargetType
    {
        ShootInitializer = 1,
        Bullet = 2,
        HitObject = 3
    }
}
