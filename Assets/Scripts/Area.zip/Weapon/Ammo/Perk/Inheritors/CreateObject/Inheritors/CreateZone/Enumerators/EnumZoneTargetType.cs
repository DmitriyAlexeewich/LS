﻿namespace Assets.Scripts.Weapon.Ammo.Perk.Inheritors.CreateObject.Inheritors.CreateZone.Enumerators
{
    public enum EnumZoneTargetType
    {
        ShootInitializer = 1,
        Bullet = 2,
        HitObject = 3
    }
}
