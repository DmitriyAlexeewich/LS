﻿namespace Assets.Scripts.Area.Models
{
    public class ZoneScale
    {
        public int ScaleTimeStep { get { return 10; } }

        protected int _maxiableScale = 20;
    }
}
