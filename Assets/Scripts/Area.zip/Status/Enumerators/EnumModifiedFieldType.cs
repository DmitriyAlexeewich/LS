﻿namespace Assets.Scripts.Status.Enumerators
{
    public enum EnumModifiedFieldType
    {
        Current = 1,
        Min = 2,
        Max = 3
    }
}
