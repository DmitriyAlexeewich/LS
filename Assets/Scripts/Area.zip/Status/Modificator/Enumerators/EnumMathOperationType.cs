﻿namespace Assets.Scripts.Status.Modificator.Enumerators
{
    public enum EnumMathOperationType
    {
        Summation = 1,
        Subtraction = 2,
        Multiplication = 3,
        Division = 4
    }
}
