﻿using Assets.Scripts.Weapon.Bullet.Enumerators;
using Assets.Scripts.Weapon.Bullet.Models;
using Assets.Scripts.Weapon.Effects.Enumerators;
using Assets.Scripts.Weapon.Model.Enumerators;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Unity.Collections;
using UnityEngine;


[RequireComponent(typeof(Damage))]
public abstract class Bullet : MonoBehaviour
{
    /*
    Transform BulletTransformComponent;

    float Damage;    
    EnumMagicType MagicType;

    Damage DamageComponent;

    public void Construct(BulletDataModel BulletData)
    {
        DamageComponent = this.gameObject.GetComponent<Damage>();
        DamageComponent.Construct(BulletData.DamageData);
        MagicType = BulletData.MagicType;
    }

    public abstract void StartBullet(Vector3 StartPosition, Vector3 DestinationPoint, Transform BulletTransform);
    
     BulletTransformComponent.position = DestinationPoint;
                RaycastBullet(StartPosition);
     


    void RaycastBullet(Vector3 Start)
    {
        var hit = new RaycastHit();
        isBulletRaycastHit(Start, BulletTransformComponent.position, ref hit);
        if (hit.collider != null)
        {
            
        }
        BulletHit(hit);
    }

    

    protected void BulletHit(RaycastHit Hit)
    {
        if (Hit.collider != null)
        {
            var hitTransform = Hit.transform;
            if (hitTransform.gameObject.tag == "Enemy")
            {
                
            }
            else
                Debug.Log(1);
        }
        DestroyBullet();
    }

    void DestroyBullet()
    {
        Destroy(this.gameObject);
    }

    protected bool isBulletRaycastHit(Vector3 Start, Vector3 End, ref RaycastHit Hit)
    {
        if (Physics.Linecast(Start, End, out Hit))
            return true;
        return false;
    }
    */
}