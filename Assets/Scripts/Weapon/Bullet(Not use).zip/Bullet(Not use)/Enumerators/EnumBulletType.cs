﻿using System;
using System.Collections.Generic;
using System.ComponentModel;

namespace Assets.Scripts.Weapon.Bullet.Enumerators
{
    public enum EnumBulletType
    {
        Bullet = 1,
        Arrow = 2,
        Plasma = 3,
        Rocket = 4
    }
}
