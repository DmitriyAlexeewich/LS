using Assets.Scripts.Weapon.Bullet.Models;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(LifeTime))]
[RequireComponent(typeof(Speed))]
public class PhysicsBullet : Bullet
{
    /*
    Transform BulletTransformComponent;

    float Diameter;
    List<Vector3> CheckHitPoints;
    float CheckHitPointsDistance;

    LifeTime LifeTimeComponent;
    Speed SpeedComponent;

    IEnumerator FlyBulletCoroutine;

    public void Construct(PhysicsBulletDataModel PhysicsBulletData)
    {
        base.Construct(PhysicsBulletData);
        LifeTimeComponent = this.gameObject.GetComponent<LifeTime>();
        LifeTimeComponent.Construct(PhysicsBulletData.LifeTimeData);
        SpeedComponent = this.gameObject.GetComponent<Speed>();
        SpeedComponent.Construct(PhysicsBulletData.SpeedData);
        Diameter = PhysicsBulletData.Diameter;
        CheckHitPoints = PhysicsBulletData.CheckHitPoints;
        CheckHitPointsDistance = PhysicsBulletData.CheckHitPointsDistance;

    }

    public override void StartBullet(Vector3 StartPosition, Vector3 DestinationPoint, Transform BulletTransform)
    {
        BulletTransformComponent = BulletTransform;
        BulletTransformComponent.LookAt(DestinationPoint);
        StartFlyBullet();
    }

    void StartFlyBullet()
    {
        FlyBulletCoroutine = FlyBullet();
        StartCoroutine(FlyBulletCoroutine);
    }

    IEnumerator FlyBullet()
    {
        LifeTimeComponent.AddStatusModifier(MagicType, 1, false, true);
        var hit = new RaycastHit();
        while ((!LifeTimeComponent.isTimeOver()) && (!isBulletPhysicsHit(ref hit)))
        {
            BulletTransformComponent.position += BulletTransformComponent.forward * speedStatusComponent.CurrentValue * Time.deltaTime;
            yield return null;
        }
        BulletHit(hit);
    }

    bool isBulletPhysicsHit(ref RaycastHit Hit)
    {
        for (int i = 0; i < CheckHitPoints.Count; i++)
        {
            var secondPosition = (BulletTransformComponent.TransformDirection(CheckHitPoints[i]) * CheckHitPointsDistance) + BulletTransformComponent.position;
            if (isBulletRaycastHit(BulletTransformComponent.position, secondPosition, ref Hit))
                return true;
        }
        return false;
    }
    */
}
