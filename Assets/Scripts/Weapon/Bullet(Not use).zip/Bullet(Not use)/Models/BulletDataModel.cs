﻿using Assets.Scripts.Stats.Model;
using Assets.Scripts.Weapon.Bullet.Enumerators;
using Assets.Scripts.Weapon.Effects.Enumerators;
using System;
using System.Collections.Generic;
using UnityEngine;

namespace Assets.Scripts.Weapon.Bullet.Models
{
    [System.Serializable]
    public class BulletDataModel
    {/*

        public StatusDataModel DamageData { get { return _DamageData; } }
        public EnumMagicType MagicType { get { return _MagicType; } }


        
        [SerializeField]
        private DamageDataModel _DamageData;
        [SerializeField]
        private EnumMagicType _MagicType;


        public BulletDataModel(float NewDamage, EnumMagicType NewMagicType)
        {
            var magicTypes = new HashSet<EnumMagicType>();
            magicTypes.Add(NewMagicType);
            _DamageData = new DamageDataModel(magicTypes, NewDamage);
            _MagicType = NewMagicType;
        }*/
    }
}
