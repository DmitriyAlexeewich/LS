﻿using Assets.Scripts.Weapon.Effects.Enumerators;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Path : MonoBehaviour
{
    [SerializeField]
    EnumPathType _Type;
    [SerializeField]
    EnumImpactType _Impact;
    [SerializeField]
    EnumMagicType _Magic;
    [SerializeField]
    float _ImpactPower;
    [SerializeField]
    float _Length;
    [SerializeField]
    float _Width;
    [SerializeField]
    float _Lifetime;
    [SerializeField]
    float _ImpactTime;

    Transform _transform;
    Vector3 _lastPosition;
    bool _hasData = true;//standart false

    public void Constructor(EnumPathType Type, EnumImpactType Impact, EnumMagicType Magic, float ImpactPower, float Length, float Width, float Lifetime, float ImpactTime)
    {
        _Type = Type;
        _Impact = Impact;
        _Magic = Magic;
        _ImpactPower = ImpactPower;
        _Length = Length;
        _Width = Width;
        _Lifetime = Lifetime;
        _ImpactTime = ImpactTime;
        _hasData = true;
    }

    private void Start()
    {
        _transform = this.gameObject.GetComponent<Transform>();
        _lastPosition = _transform.position;
    }

    private void Update()
    {
        if (_hasData)
        {
            if (_Type == EnumPathType.Ground)
            {
                RaycastHit hit;
                if (Physics.Raycast(_transform.position, Vector3.down, out hit))
                {
                    var bufferDistance = GetGroundDistance(hit.point, _lastPosition);
                    if (bufferDistance > _Length)
                    {
                        Transform pathBlockTransform = CreatePathTransform(EnumAreaForm.Cube);
                        pathBlockTransform.position = hit.point - (hit.point - _lastPosition) * ((bufferDistance - _Length) / 2);
                        pathBlockTransform.position = new Vector3(pathBlockTransform.position.x, hit.point.y, pathBlockTransform.position.z);
                        _lastPosition = pathBlockTransform.position;
                        pathBlockTransform.rotation = Quaternion.Euler(0, _transform.rotation.eulerAngles.y, 0);
                        pathBlockTransform.localScale = new Vector3(_Width, 0.2f, _Length);
                    }
                }
                else
                    _lastPosition = new Vector3(_transform.position.x, _lastPosition.y, _transform.position.z);
            }
            else
            {
                var bufferDistance = Vector3.Distance(_transform.position, _lastPosition);
                if (bufferDistance > _Length * 2)
                {
                    Transform pathBlockTransform = CreatePathTransform(EnumAreaForm.Cylinder);
                    pathBlockTransform.position = _transform.position - (_transform.position - _lastPosition) * (bufferDistance - _Length * 2);
                    pathBlockTransform.rotation = Quaternion.Euler(_transform.rotation.eulerAngles.x + 90, _transform.rotation.eulerAngles.y, _transform.rotation.eulerAngles.z);
                    pathBlockTransform.localScale = new Vector3(_Width, _Length, _Width);
                    _lastPosition = pathBlockTransform.position;
                }
            }
        }
    }

    private float GetGroundDistance(Vector3 A, Vector3 B)
    {
        return Mathf.Pow(A.x - B.x, 2) + Mathf.Pow(A.z - B.z, 2);
    }

    private Transform CreatePathTransform(EnumAreaForm Form)
    {
        Transform pathTransform;
        if (Form == EnumAreaForm.Cylinder)
        {
            pathTransform = GameObject.CreatePrimitive(PrimitiveType.Cylinder).GetComponent<Transform>();
            Destroy(pathTransform.gameObject.GetComponent<CapsuleCollider>());
            var collider = pathTransform.gameObject.AddComponent<MeshCollider>();
            collider.convex = true;
        }
        else
            pathTransform = GameObject.CreatePrimitive(PrimitiveType.Cube).GetComponent<Transform>();
        pathTransform.gameObject.layer = 2;
        return pathTransform;
    }
}
