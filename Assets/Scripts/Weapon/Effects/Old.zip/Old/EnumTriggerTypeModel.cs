﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assets.Scripts.Weapon.Effects
{
    public enum EnumTriggerTypeModel
    {
        Single = 1,
        Burst = 2,
        Push = 3
    }
}
