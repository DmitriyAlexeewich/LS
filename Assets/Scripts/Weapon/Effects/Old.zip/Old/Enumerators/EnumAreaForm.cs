﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assets.Scripts.Weapon.Effects.Enumerators
{
    public enum EnumAreaForm
    {
        Sphere = 1,
        Cylinder = 2,
        Cube = 3
    }
}
