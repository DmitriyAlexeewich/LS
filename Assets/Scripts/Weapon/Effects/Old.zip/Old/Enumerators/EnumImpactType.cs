﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assets.Scripts.Weapon.Effects.Enumerators
{
    public enum EnumImpactType
    {
        /*
         * Electro
        */
        //1 level
        MomentDamage = 1,
        ScopeDamage = 2,
        //2 level
        NearDamage = 3,
        NearStop = 4,
        //3 level
        AddDeathMagicBonus = 5,
        AddDeathHealBonus = 6,
        AddDeathExplosionBonus = 7,
        AddDeath = 8,
    }
}
