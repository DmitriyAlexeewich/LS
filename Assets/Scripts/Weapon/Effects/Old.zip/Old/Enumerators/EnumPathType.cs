﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assets.Scripts.Weapon.Effects.Enumerators
{
    public enum EnumPathType
    {
        [Description("Путь создаётся на земле")]
        Ground = 1,
        [Description("Путь создаётся в полёте")]
        Fly = 2
    }
}
