﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assets.Scripts.Weapon.Effects.Enumerators
{
    public enum EnumMagicType
    {
        [Description("Электрическое воздействие")]
        Electro = 1,
        [Description("Гравитационное воздействие")]
        Gravity = 2,
        [Description("Квантовое воздействие")]
        Kvant = 3
    }
}
