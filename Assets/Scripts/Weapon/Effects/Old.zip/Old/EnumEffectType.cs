﻿
using System.ComponentModel;

public enum EnumEffectType
{
    [Description("Путь до определённой точки, либо до объекта")]
    Path = 1,
    [Description("Зона в определённой точки, либо на позиции объекта")]
    Area = 2,
    [Description("Клонирование пули, работает только на оружии")]
    CloneBullet = 3,
    [Description("Рикошет при соприкосновении, работает только при HitEvent")]
    Ricoshet = 4,
    [Description("Создаёт платформу в месте попадании пули, работает только при HitEvent")]
    Platform = 5,
    [Description("Создаёт вторую пулю, работает только на оружии и работает только при ShootEvent")]
    SecondBullet = 6,
    [Description("Создаёт физический импульс в определённой точки, либо на позиции объекта")]
    PhysicsImpulse = 7,
    [Description("Восстанавливает один из параметров")]
    Restore = 8,
    [Description("Создаёт связь с объектами либо в определённых координатах")]
    ObjectLink = 9
}
