﻿using Assets.Scripts.Weapon.Effects.Enumerators;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace Assets.Scripts.Weapon.Effects.Models
{
    public class AreaModel
    {
        public EnumAreaType Type { get; }
        public Vector3 StartSize { get; }
        public Vector3 EndSize { get; }
        public float Gravity { get; }
        public EnumImpactType Impact { get; }
        public EnumMagicType Magic { get; }
        public float ImpactTime { get; }
        public float ImpactPower { get; }
        public float Lifetime { get; }
        public float SizeUpSpeed { get; }

        public AreaModel(EnumAreaType NewType, Vector3? NewStartSize, Vector3 NewEndSize, float? NewGravity, EnumImpactType NewImpact, EnumMagicType NewMagic, 
            float NewImpactTime, float NewImpactPower, float NewLifetime, float? NewSizeUpSpeed)
        {
            Type = NewType;
            if (NewStartSize != null)
                StartSize = NewStartSize.Value;
            else
                StartSize = Vector3.one * -1;
            EndSize = NewEndSize;
            if (NewGravity != null)
                Gravity = NewGravity.Value;
            else
                Gravity = -1f;
            Impact = NewImpact;
            Magic = NewMagic;
            ImpactTime = NewImpactTime;
            ImpactPower = NewImpactPower;
            Lifetime = NewLifetime;
            if (NewSizeUpSpeed != null)
                SizeUpSpeed = NewSizeUpSpeed.Value;
            else
                SizeUpSpeed = -1f;
        }
    }
}
