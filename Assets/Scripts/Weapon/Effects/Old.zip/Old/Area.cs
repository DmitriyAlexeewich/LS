﻿using Assets.Scripts.Weapon.Effects.Enumerators;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Area : MonoBehaviour
{
    [SerializeField]
    EnumAreaType _Type;
    [SerializeField]
    Vector3 _StartSize;
    [SerializeField]
    Vector3 _EndSize;
    [SerializeField]
    float _Gravity;
    [SerializeField]
    EnumImpactType _Impact;
    [SerializeField]
    EnumMagicType _Magic;
    [SerializeField]
    float _ImpactTime;
    [SerializeField]
    float _ImpactPower;
    [SerializeField]
    float _Lifetime;
    [SerializeField]
    float _AreaSizeUpSpeed;

    Transform _transform;
    bool _hasData = true;//standart false

    public void Constructor(EnumAreaType Type, Vector3? StartSize, Vector3 EndSize, float? Gravity, EnumImpactType Impact, EnumMagicType Magic, float? ImpactTime, float? ImpactPower, float Lifetime, float? AreaSizeUpSpeed)
    {
        _transform = this.gameObject.GetComponent<Transform>();
        _Type = Type;
        if (StartSize == null)
            _StartSize = Vector3.zero;
        else
            _StartSize = StartSize.Value;
        _EndSize = EndSize;
        _Impact = Impact;
        _Magic = Magic;
        _Lifetime = Lifetime;
        _Gravity = Gravity.Value;
        _ImpactTime = ImpactTime.Value;
        _ImpactPower = ImpactPower.Value;
        _AreaSizeUpSpeed = AreaSizeUpSpeed.Value;
        _hasData = true;
    }

    private void Start()
    {
        _transform = this.gameObject.GetComponent<Transform>();
    }

    void Update()
    {
        if (_hasData)
        {
            if ((_StartSize != Vector3.zero) && (_transform.localScale.x <= _EndSize.x))
            {
                _transform.localScale += (_EndSize - _transform.localScale).normalized * Time.deltaTime * _AreaSizeUpSpeed;
                if (_transform.localScale.x > _EndSize.x)
                    _transform.localScale = _EndSize;
            }
            _Lifetime -= Time.deltaTime;
            if (_Lifetime < 0)
                Destroy(this.gameObject);
        }
    }

    void OnTriggerEnter(Collider other)
    {
        Debug.Log(other.gameObject);
    }
}
